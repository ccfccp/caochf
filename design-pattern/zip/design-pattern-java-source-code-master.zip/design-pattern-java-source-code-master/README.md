# 《设计模式 Java版》 源码

Sunny在CSDN技术博客中陆续发表了100多篇与设计模式学习相关的文章，涵盖了七个面向对象设计原则和24个设计模式（23个GoF设计模式 +  简单工厂模式），为了方便大家学习，http://quanke.name 现将所有文章的进行了整理，方便大家下载阅读，希望能给各位带来帮助！


阅读地址：https://quanke.gitbooks.io/design-pattern-java/content/

下载地址：https://www.gitbook.com/book/quanke/design-pattern-java/

源码下载地址：https://github.com/quanke/design-pattern-java-source-code.git

public interface AirConditioner
{
	public void changeTemperature();
}
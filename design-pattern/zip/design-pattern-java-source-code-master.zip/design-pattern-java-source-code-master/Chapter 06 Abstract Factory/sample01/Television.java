public interface Television
{
	public void play();
}
public interface Sort
{
	public abstract int[] sort(int arr[]);
}